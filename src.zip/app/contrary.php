<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contrary extends Model
{
    protected $fillable = [
        'name',
        'contrary'
    ];
}
