<?php

return [
    "accept" => "接受",
    "herbal" => "制药",
    "treat_state" => [
        "accept" => "ACCEPT",
        "waiting_treatment" => "WAITING_TREATMENT",
        "treating" => "TREATING",
        "before_treating_pay" => "BEFORE_TREATING_PAY",
        "after_treating_pay" => "AFTER_TREATING_PAY",
        "close" => "CLOSE"
    ]
];
