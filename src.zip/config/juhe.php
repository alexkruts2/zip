<?php

return [
    'mobile' => [
        'url' => 'http://apis.juhe.cn/mobile/get',
        'appkey' => '2da14c7ec7ecf1b128e753d2bd0b3da8'
    ],
    'ip' => [
        'url' => 'http://apis.juhe.cn/ip/ip2addr',
        'appkey' => '1ee3e6f19dd2aba4283d15391e527747'
    ],
    'exchange' => [
        'url' => 'http://web.juhe.cn:8080/finance/exchange/rmbquot',
        'appkey' => '8a796291190bc9d59675c7fa6e9b5dd6'
    ]
];