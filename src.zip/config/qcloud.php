<?php
/**
 * Created by PhpStorm.
 * User: MONO
 * Date: 7/30/2018
 * Time: 5:46 PM
 */

return [
    'cos' => [
        'appid' => 1251005197,
        'secretid' => 'AKIDkPtBHCBEllZBaD4CtSp11pgjnRtCrwAB',
        'secretkey' => 'xlWjlzUqREqUjcXGn9JG1aygQWas0vFm',
        'region'=>'ap-shanghai',
        'image_bucket'=>'hcimg-1251005197',
        'video_bucket'=>'hcvideo-1251005197',
        'file_bucket'=>'hcfile-1251005197'
    ]
];
