$(function(){
    $(".question-area").height($(".question-area").width()*0.751);

});
